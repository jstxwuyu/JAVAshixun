function f1(){
	alert("hello");
}
function f2(){
	alert("你好");
}